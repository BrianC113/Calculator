
/**
 * Controller class acts as the bridge between the View and the Model.
 * It will receive input from the user in the View class.
 * Converts input into numeric values and calls upon the method in the the Model class to perform the calculation.
 * @Brian Chinhamora
 * @18/01/2026
 */
public class Controller{
    
    Model model; //Controller talks to Model
    View view; //Controller reads user's input from View
    // Bridge method: called by the View to delegate respomsibilites to Model.
    void doCalculate(String action){
        
        try{
            int num1 = Integer.parseInt(view.tfNum1.getText().trim()); // https://www.geeksforgeeks.org/java/how-to-convert-a-string-to-an-int-in-java/
            int num2 = Integer.parseInt(view.tfNum2.getText().trim());
            
            switch(action){
                case "+":
                    model.doAdd(num1, num2);
                    break;
                    
                case "-":
                    model.doSub(num1, num2);
                    break;
                    
                case "x":
                    model.doMul(num1, num2);
                    break;
                    
                case "/":
                    model.doDiv(num1, num2);
                    break;
                    
                default: model.unimplementedOperation(action);
            
            }
            
            
        } catch (NumberFormatException e){
            model.unimplementedOperation("Error");
        }
    }
}
