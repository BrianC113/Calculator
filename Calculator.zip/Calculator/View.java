import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
/**
 * View class is responsible for what you actually see on the screen.
 *
 * @Brian Chinhamora
 * @18/01/2026
 */
public class View {
    
    int H = 500;         // Height of window pixels 
    int W = 500;         // Width  of window pixels 

    Controller controller;  // View talks to Controller
    
    //components of the user interface
    TextField  tfNum1,tfNum2; // User input fields
    private TextField  tfResult; //Displays the calculation result, or a reminder message, eg: "The calculation ÷ not implemented yet"

    private Label laCurrentOperator; // Displays "Operator" by default, or the selected operator symbol (+, -, etc.) after an operation button is clicked.
    private Label laResultStatus; // Displays "Result will appear below" by default, or "=" when a calculation succeeds.
    
    private GridPane   gridPane;      // main layout manager grid
    private TilePane   buttonPane;    // tiled area for operator (+ - X ÷) buttons
    
    public void start(Stage window){
        window.setTitle("Simple Calculator");
        
        // Create layout managers and assign a CSS ID for styling. 
        // CSS is only for appearance; not needed for functionality, 
        // You can ignore the css usage for now
        gridPane = new GridPane();
        gridPane.setId("GridPaneStyle");  
        buttonPane = new TilePane();          
        buttonPane.setId("ButtonsPaneStyle");    
        
        //create UI controls and add them to layout manager
        tfNum1 = new TextField();
        tfNum1.setPromptText("Enter first number: ");
        gridPane.add(tfNum1,1,1);
        
        laCurrentOperator = new Label("Operator");
        laCurrentOperator.setId("laCurrentOperator");
        gridPane.add(laCurrentOperator,1,2);
        
        tfNum2 = new TextField();
        tfNum2.setPromptText("Enter second number: ");
        gridPane.add(tfNum2,1,3);
        
        laResultStatus = new Label("Result will appear below");
        laResultStatus.setId("laResultStatus");
        gridPane.add(laResultStatus,1,4);
        
        tfResult = new TextField();
        tfResult.setEditable(false);
        gridPane.add(tfResult,1,5);
        
        // Buttons - these are laid out on a TilePane,
        // then the whole tile pane is added to the main gridPane
        String[] operatorSymbols = { "+","-","x","/" }; // Symbols shown on operator buttons.

        //loop through the array, making a Button object for each symbol
        for(String text: operatorSymbols){
            Button btn = new Button(text);
            buttonPane.getChildren().add(btn);
            btn.setOnAction(this::buttonClick); //Sets the action to be performed (event handler) when the button is clicked.
        } //this:: buttonClick - Refers to the current object of the class (View here) that defines buttonClick.
        
        gridPane.add(buttonPane,1,6);
        Scene scene = new Scene(gridPane,W,H);
        scene.getStylesheets().add("Calculator.css"); // tell the app to use our css
        window.setScene(scene);
        window.show();
    }
    

    
    private void buttonClick(ActionEvent event){
        // Get the button that was clicked
        Button btn = (Button) event.getSource();
        
        if (controller != null){
            String text = btn.getText();   // get the button text
            
            //passes the button text to the Controller class
            controller.doCalculate(text);  
        }
    }
    
    //This method is called by the Model to update the UI.
    void update(String currentOperator, String resultStatus, String result){       
        laCurrentOperator.setText(currentOperator);
        laResultStatus.setText(resultStatus);
        tfResult.setText(result);    
    }
}

