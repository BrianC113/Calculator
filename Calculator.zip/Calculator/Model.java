
/**
 * Model class is what handles the data logic and actions coming from the view
 * In this particular project to performs the arithmetic operations and stores the result 
 * @Brian Chinhamora
 * @18/01/2026
 */
public class Model {
    
    Calculation calculation; // Model uses the business class Calculation - which does the math
    
    View view; //Reference to the View; Model tells View to update itself
    
    // The three used to update the View
    private String currentOperator; // Current operator to display in the View
    private String resultStatus;    // Status indicator (e.g., "Result will appear below" or "=") for the View
    private String result;          // Calculation Result or failure message for the View

    void doAdd(int num1, int num2){
        currentOperator = "+";
        try{
            int resultNum = calculation.add(num1, num2);
            result = String.valueOf(resultNum);
            resultStatus = "=";
        }
        catch(Exception e){
            resultStatus = "Your result is: ";
            result = "Only whole numbers";
        }
        update();
    }
    
    void doSub(int num1, int num2){
        currentOperator = "-";
        try{
            int resultNum = calculation.sub(num1, num2);
            result = String.valueOf(resultNum);
            resultStatus = "=";
        }
        catch(Exception e){
            resultStatus = "Your result is: ";
            result = "Only whole numbers";
        }
        update();
    }
    
    void doMul(int num1, int num2){
        currentOperator = "x";
        try{
            int resultNum = calculation.mul(num1, num2);
            result = String.valueOf(resultNum);
            resultStatus = "=";
        }
        catch(Exception e){
            resultStatus = "Your result is: ";
            result = "Only whole numbers";
        }
        update();
    }
    
    void doDiv(int num1, int num2){
        if (num2 == 0) {
            currentOperator = "/";
            resultStatus = "Error!";
            result = "Can't divide by 0";    //Call for error when dividing by zero
        } else {
            int resultNum = calculation.div(num1, num2);
            result = String.valueOf(resultNum);
            resultStatus = "=";
        }
        update();
    }
    
    
    void unimplementedOperation(String op){
        currentOperator = op;
        resultStatus = "Result will appear below";
        result = op + ". Not implemented";
        update();
    }
    
    // Notifies the View to refresh the UI; Called by the Model itself when data changes.
    private void update(){
        view.update(currentOperator,resultStatus, result);
    }
}
