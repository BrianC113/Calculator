import javafx.application.Application;
import javafx.stage.Stage;

// Calculator App Main class
/**
 * This is the entry point of the application.
 * It launches the JavaFX app by creating the Model, View, Controller and Calculation objects.
 * Links them together so that they can communicate.
 * @Brian Chinhamora
 * @19/01/2026
 */
public class Main extends Application {
    
    public static void main( String args[] ){
        // The main method only gets used when launching from the command line
        // launch initialises the system and then calls start
        // In BlueJ, BlueJ calls start itself
        launch(args);
    }
    

    @Override
    public void start(Stage window){
        
        // Create  Model, View and Controller objects, as well as calculator object
        Model model = new Model();
        View view = new View();
        Controller  controller = new  Controller();
        Calculation calculation = new Calculation();
        
        // Link them together so they can talk to each other
        view.controller = controller;
        controller.model = model;
        controller.view = view;
        model.view = view;
        model.calculation = calculation;
       
        // start up the GUI (view)
        view.start(window);         
    }
}
